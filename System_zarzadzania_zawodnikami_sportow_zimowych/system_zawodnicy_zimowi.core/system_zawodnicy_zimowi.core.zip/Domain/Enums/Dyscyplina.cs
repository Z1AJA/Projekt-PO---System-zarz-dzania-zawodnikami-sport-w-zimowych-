﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace system_zawodnicy_zimowi.core.Domain.Enums
{
    public enum Dyscyplina
    {
        NarciarstwoAlpejskie = 1,
        Snowboard = 2
    }
}
