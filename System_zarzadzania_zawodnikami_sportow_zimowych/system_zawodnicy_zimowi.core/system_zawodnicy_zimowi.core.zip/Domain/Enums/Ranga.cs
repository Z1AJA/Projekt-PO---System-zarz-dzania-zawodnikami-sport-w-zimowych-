﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace system_zawodnicy_zimowi.core.Domain.Enums
{
    public enum Ranga
    {
        Junior = 1,
        Amator = 2,
        SemiPro = 3,
        Pro = 4
    }
}
